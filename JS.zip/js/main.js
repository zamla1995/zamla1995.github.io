"use strict";

var GeoTIFF = require("./geotiff.js");

/**
 * Main parsing function for GeoTIFF files.
 * @param {(string|ArrayBuffer)} data Raw data to parse the GeoTIFF from.
 * @param {Object} [options] further options.
 * @param {Boolean} [options.cache=false] whether or not decoded tiles shall be cached.
 * @returns {GeoTIFF} the parsed geotiff file.
 */
var parse = function parse(data, options) {
  var rawData, i, strLen, view;
  if (typeof data === "string" || data instanceof String) {
    rawData = new ArrayBuffer(data.length * 2); // 2 bytes for each char
    view = new Uint16Array(rawData);
    for (i = 0, strLen = data.length; i < strLen; ++i) {
      view[i] = data.charCodeAt(i);
    }
  } else if (data instanceof ArrayBuffer) {
    rawData = data;
  } else {
    throw new Error("Invalid input data given.");
  }
  return new GeoTIFF(rawData, options);
};

if (typeof module !== "undefined" && typeof module.exports !== "undefined") {
  module.exports.parse = parse;
}
if (typeof window !== "undefined") {
  window["GeoTIFF"] = { parse: parse };
}